/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_135215243_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `wp_135215243_actionscheduler_groups` (`group_id`, `slug`) VALUES (1,'wc-admin-notes');
INSERT INTO `wp_135215243_actionscheduler_groups` (`group_id`, `slug`) VALUES (2,'action-scheduler-migration');
INSERT INTO `wp_135215243_actionscheduler_groups` (`group_id`, `slug`) VALUES (3,'woocommerce-db-updates');
INSERT INTO `wp_135215243_actionscheduler_groups` (`group_id`, `slug`) VALUES (4,'wc_update_product_lookup_tables');
