/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_135215243_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `wp_135215243_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES (1,'inquiriesicertifynetau','$P$BdVPeRO4fOhMKJpLNhXLKBVuMT5YUF/','inquiriesicertifynetau','inquiries@icertify.net.au','','2017-10-23 06:33:18','',0,'inquiriesicertifynetau');
INSERT INTO `wp_135215243_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES (2,'lachmcg1','$P$B6tDZOfhBuOvWIsjXkdcLnPyG2e8jJ/','lachmcg1','lachlan.mcgoldrick@gmail.com','','2020-05-05 02:47:07','',0,'lachmcg1');
INSERT INTO `wp_135215243_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES (3,'merayabba','$P$BjmUAAPXGxvFIBVqEU1uKK2KlFzPea1','merayabba','s3667590@student.rmit.edu.au','','2020-08-15 03:59:12','',0,'merayabba');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('4','kanikaMehra','$P$BEk6eftjQoHaH6hu0yeLWRSxuBHq5Z/','kanikamehra','s3688154@student.rmit.edu.au','http://icertify.net.au','2020-08-25 09:50:14','1598349014:$P$B36AJGGoWB9Ye084iWx2LtBUlyN/vR0','0','kanika Mehra');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('5','Emma','$P$BoIJvaSGc4cPlmiAg3q0F3p53z6AS./','emma','s3722355@student.rmit.edu.au','https://icertify.net.au','2020-08-25 09:51:40','1598349100:$P$BeX8svynjwdgeeOzFG.gvCCZfcKMYn0','0','Aimerance Ndayisaba');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('4','kanikaMehra','$P$BEk6eftjQoHaH6hu0yeLWRSxuBHq5Z/','kanikamehra','s3688154@student.rmit.edu.au','http://icertify.net.au','2020-08-25 09:50:14','1598349014:$P$B36AJGGoWB9Ye084iWx2LtBUlyN/vR0','0','kanika Mehra');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('4','kanikaMehra','$P$BqJ.yssDdJHw7RGzhBITYv/Y9X3Twm.','kanikamehra','s3688154@student.rmit.edu.au','http://icertify.net.au','2020-08-25 09:50:14','','0','kanika Mehra');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('6','kanikaMehra','$P$BXxGM/ZkcZ5cstnaWoC54XpjyQQKJr.','kanikamehra','s3688154@student.rmit.edu.au','https://icertify.net.au','2020-08-25 09:58:34','1598349514:$P$B40Mu/8OBIMnuUY0nHEVfyNr3gsr4b.','0','Kanika Mehra');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('5','Emma','$P$Bfo4/yfcSAE2fp2BEy6qvsFi.Y84ec0','emma','s3722355@student.rmit.edu.au','https://icertify.net.au','2020-08-25 09:51:40','','0','Aimerance Ndayisaba');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('5','Emma','$P$Bfo4/yfcSAE2fp2BEy6qvsFi.Y84ec0','emma','s3722355@student.rmit.edu.au','https://icertify.net.au','2020-08-25 09:51:40','1598349765:$P$B3BrAUEQ8NVaKX6/suemf8QABzwirQ.','0','Aimerance Ndayisaba');
REPLACE INTO `wp_135215243_users` (`ID`,`user_login`,`user_pass`,`user_nicename`,`user_email`,`user_url`,`user_registered`,`user_activation_key`,`user_status`,`display_name`) VALUES ('7','Emma','$P$Beeocjrh1r3LWNSEKoFWvS2UYQ6nmV/','emma','s3722355@student.rmit.edu.au','https://icertify.net.au','2020-08-25 10:05:08','1598349909:$P$BT59CG.vGf3QYBcqVoijvr475LkRIJ/','0','Aimerance Ndayisaba');
